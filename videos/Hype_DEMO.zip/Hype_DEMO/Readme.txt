		      Hype - the Time Quest DEMO
		      Ubi Soft Entertainment

---------------------------------------------------------------
If you are viewing this text on-screen with Notepad, select the
"Automatic new line" option in the Edit menu so that the text
is automatically adjusted to the width of your window.
---------------------------------------------------------------         
Thank you for playing "Hype - the Time Quest". 
We hope you enjoy the game.

You are strongly advised to read this document for the most
up-to-date information on the game and its installation.
===============================================================

TABLE OF CONTENTS
==================
I.    SYSTEM REQUIREMENTS
II.   INSTALLING THE GAME
      Advice on Installation
      Access Path
III.  INSTALLATION OPTIONS
      According to your 3D Card
      According to your Computer's Memory
IV.   3D CARD DRIVERS
V.    HINTS
VI.   MAXIMISING THE GAME'S PERFORMANCE
VII.  UNINSTALLING THE GAME
VIII. MENUS
IX.   GAMEPAD AND KEYBOARD CONTROLS 
X.    TROUBLESHOOTING
XI.   WHERE TO CONTACT UBI SOFT ENTERTAINMENT



I. SYSTEM REQUIREMENTS
==========================

Minimum Configuration
---------------------

Pentium 200 MMX
Windows 95, 98 or NT
32 Mb RAM
3Dfx Voodoo 1 or 2 graphics accelerator
or Direct X compatible cards
CD-ROM drive 12x minimum
Keyboard or gamepad
16 million colour monitor
16-bit Video card
16-bit sound card or higher 

Minimum installation requirements 
===========================================  
100Mb space on your hard drive

Recommended Configuration
===========================================  
Pentium 266 MMX or higher
64 Mb RAM


3D graphics cards supported by the game
---------------------------------------
Here are the Internet sites of various 3D card manufacturers 
where you can find the latest drivers for your 3D card.NVidia:
    Riva 128
    Riva 128 zx
    Riva TNT
http://www.nvidia.com

Matrox:
    G100
    G200
    Mystique (4Mo - 8Mo)
http://www.matrox.com

ATI:
    Rage Pro (4Mo - 8Mo)
http://www.atitech.ca

3Dfx:
    Voodoo Graphics
    Voodoo II
    Voodoo Rush
    Voodoo Banshee
http://www.3dfx.com

Rendition:
    V2200
http://www.rendition.com

Intel:
    I740
http://www.intel.com

3DLabs:
    Permedia 2
    Permedia 3
http://www.3Dlabs.com

S3:
    Savage 3D
http://www.S3.com


Sound cards supported by the game
---------------------------------
Creative :
    Sound Blaster 16
    Sound Blaster 32
    Sound Blaster 64  
    Sound Blaster 128
    Sound Blaster Live
    Ensoniq 64 pci 

Turtle Beach:
    Montego 2
    Malibu Surround 64
    Daytona pci
    Montego A3D

Diamond:
    Monster Sound mx200

Guillemot:
    Maxi 16
    Maxi ess
    Maxi 64

Yamaha:
    Waveforce 192 digital (wf192d)

Videologic:
    SonicStorm pro pci

Xitel:
    Storm VX


II. INSTALLING THE GAME
====================

Installation Advice
-------------------
1. "Hype - the Time Quest" is a high-performance
   multimedia program.  This game was created to get the most
   out of your multimedia computer.  Before installing the program,
   or before starting to play, you are advised to close any
   applications that may still be open. 

2. Make sure you have the latest drivers for your 3D card.
   This is extremely important for maximum game performance.
   Refer to "Installation Options According to your 3D Card".



III. INSTALLATION OPTIONS
=================================

You can choose different types of installation on your
computer. This option will depend on your 3D card and how much
memory you have on your computer.


According to your 3D Card
-------------------------
"Hype - the Time Quest" is optimised to function
with two types of 3D card drivers: DirectX 6.1 and Glide3.01

By default, the installation will suggest the DirectX6 version,
as this is the easiest to install.However, if you have a 3Dfx card, the game's performance
will be increased with the Glide 3.01 version.
If you do not want the default installation option,
click on "change", then choose an installation type
from the list suggested to you.

1- If your card works with 3Dfx technology and you are
   ready to update the drivers for your card,
   choose version Glide3.

2- If your card is not a 3Dfx card choose DirectX 6.1.    In both cases, refer to your video card user's manual 
   for relevant details and requirements. 

If the installation system detects an out-of-date version of  
the drivers required, it will install the up-to-date versions
if necessary. Only with these versions will you 
be able to play "Hype - the Time Quest".
When you start the game, the driver versions will be tested
and an error message will inform you if you do not have the
latest drivers (See "3D card drivers").

Note:
=====
* If you are using an AGP 3D card.
The game requires a minimum 8Mb of AGP memory. You can adjust 
this amount on your computer's BIOS.  
If you do not have enough AGP memory, you will get an error message when you start the game.


* If you are using an AGP 3D card,
you may have difficulties running the game properly.
Refer to the "UbiConfig_EN.txt" for further information.
* If you are installing the game in Windows NT,
the default installation type will also be
DirectX6, but you are advised to choose Glide3. In this case,
refer to the "Installation of Glide3.txt" document to update
your 3D card's drivers.




IV. 3D CARD DRIVERS
=======================

It is EXTREMELY important that you have all the latest drivers
for your 3D card. All 3D card manufacturers frequently update
their drivers and it is very likely that the drivers you installed
when you purchased your card have since become outdated. 

Find the latest DirectX drivers Kit at www.microsoft.com 
You need the 6.1 or better version.

Find the latest Glide drivers at www.3dfx.com
You need the 3.01 or better.

V. HINTS
========

"ALT" + "TAB"
------------
You are strongly advised against switching to other applications
by pressing "Alt" + "Tab" during the game.

Loading a level
---------------Loading a level in "Hype - the Time Quest" can take
a while owing to the large number of graphic elements
contained in the level. The progress bar for the time taken to load is not always 
accurate, since this time depends on your system.
Don't worry if your progress bar is full
and you still have to wait a few more seconds. 


How do quit the game?
--------------------
From the game, press "ESC" to pause the game.
Choose "Main Menu".

From the main menu, select "Quit".  You will be asked
to confirm your choice.



VI. MAXIMISING THE GAME'S PERFORMANCE
=====================================

You will be able to play "Hype - the Time Quest" perfectly well
on some systems and less well on others.  The game's
performance and fluidity are directly linked to the performance of
your PC, 3D card and sound card.


Here is some advice on maximising the game's fluidity.


1. If your card supports Glide3 technology (all Voodoo cards),
   select this type of installation rather than the one proposed by default. 
   Refer to the "3D card drivers" section.

2. Reduce the quality of the textures. Proceed as follows:
   * Choose "Options" from the main menu
   * Then choose "Picture"
   * Choose adjust cursor from the "Textures" line

3. If you want to optimise the game in more detail, 
   there is a utility to change graphic and sound characteristics.
   Refer to the "ubiconfig_EN.txt" document on the CD-ROM. 


VII. UNINSTALLING THE GAME
==========================


If you have already installed the game on your computer, you can
uninstall it or change the type of installation.

If you want to change the type of installation, it is best to
uninstall the game first, otherwise some files may take up
unnecessary space on your hard disk.

To uninstall the game, choose the uninstall option
in the main menu or from the Windows "Start" menu
via the following path: "Programmes\Ubi Soft\Hype - the Time 
Quest"
Choose "Uninstall Hype - the Time Quest".



VIII. MENUS
===========


Adjusting the graphic quality
-----------------------------
"Hype - the Time Quest" offers a very high graphic
quality.  However, depending on your computer's configuration,
the graphic workload can slow down the game.
 
You can access the picture control menu by selecting "Options"
from the main menu, then "picture".

You can adjust the "Graphic quality", the "screen size" and the
"textures" using the cursors.

"Graphic quality" allows you to modify the importance
of certain visual elements which require a lot of processing - for
example, Hype's shadow.

"screen size" reduces the display surface on your screen
and improves the fluidity of the game.

"Textures" modifies the quality of the textures.  The lower
the level, the more fluid the game.




Adjusting the Volume
--------------------
Some sound cards do not respond well when you adjust
the volume in certain applications.  If you have trouble 
adjusting the volume from the game, adjust the volume of your 
computer manually by double-clicking on the speaker icon
at the bottom right of your Windows screen or by going into
the control panel on your PC.

IX.  CONTROLS
=============


QWERTY keyboard
---------------
(default configuration)

Arrows    : control the character
Left shift: run (when held down)
Ctrl       : jump
Space bar  : Action
Enter      : Use magic
X          : Select/deselect sword
Z (Y in German): Select/deselect crossbow
Numpad0    : vision mode (hold down)
Delete     : Select magic
A          : Step to the left
S          : Step to the right


AZERTY keyboard
--------------
(default configuration)

Arrows    : control the character
Left caps : run (when held down)
Ctrl       : jump
Space bar     : Action
Enter     : Use magic
X          : Select/deselect sword
W          : Select/deselect crossbow
0 Ins      : vision mode (hold down)
Del       : Select magic
Q          : Step to the left
S          : Step to the right



Gamepad
-------

All 8 button gamepads are supported.

This is the configuration for a Microsoft SideWinder (c).

Button A : Jump
Button B : Action
Button C : Use magic
Button X : Select/deselect weapon
Button Y : vision mode (hold down)
Button Z : Select magic
Right button : Sidestep (hold down)
Left button : Run (hold down)


Information on directions
-------------------------------
Up button:  Up in the menus and in the inventory
		Walk forward
		Run if the run button is held down
Down button: Down in the menus and in the inventory
		Move backwards
Left button: move left in the menus and the inventory
   		Turn to the left
Right button: move right in the menus and the inventory
		Turn to the right



X. TROUBLESHOOTING
===================



Non-existent or faulty files
----------------------------
The game may not be able to find the right files on your hard drive if they do not exist or if they are faulty.

In this case, you must reinstall the program. 
To do this, you do not need to uninstall the game.
Simply restart the installation in the same way
as you did the first time.


No sound
--------------
If there is no sound or music in the game. 

* Quit the game
* Restart your computer
* Then restart the game and reload your game


Graphic Resolution Problem in Windows
-------------------------------------
If there is a problem in the game which suddenly takes you
back to Windows, the initial graphic resolution may not
have been restored. This typically leads to your desktop being
bigger than usual and you will no longer see the application icons.


To reconfigure your desktop appearance:
* Right click on the desktop
* Click on Properties
* Choose the "Settings" tab




XI. WHERE TO CONTACT UBI SOFT ENTERTAINMENT
===========================================


	    > FRANCE
            28 rue Armand Carrel
            93108 Montreuil sous bois Cedex
            Technical support : 08 36 68 46 32
            Technical support e-mail: hotline@ubisoft.fr
            Web : http://www.ubisoft.fr           

	    > CANADA
            5505 Boulevard Saint Laurent, Suite 5000
            Montr�al, Quebec H2T-1S6 Canada
            Technical support: 514-490-0887
            Technical support e-mail: tech-support@ubisoft.qc.ca
            Web: http://www.ubisoft.qc.ca

	    > GERMANY
            Zimmerstrasse 19 40215 Dusseldorf
            TE9l.: 0211 - 3380033
            Technical support e-m: redline@ubisoft.de
            Web: http://www.ubisoft.de           

	    > UK
            Vantage House 1 Weir Rd.
            Wimbledon, London. SW19 8UX.
            Tel: (0044) 0181 944 9000
            Technical support e-mail: techsupport@ubisoft.co.uk
            Web: http://www.ubisoft.co.uk/

            > USA
            625 Third Street, 3rd Floor,
            San Francisco, CA 94107
            Technical support: 514-490-0887
            Technical support e-mail: tech-support@ubisoft.com
            Web: http://www.ubisoft.com/

            > ITALY
            Indirizzo: Via Anfiteatro, 5 - 20121 Milano
            TE9l.: 02/861484
            Technical support e-mail: ubisoft@ubisoft.inet.it
            Web: http://www.ubisoft.fr/italia/
         
            > SPAIN
            Plaza De La Union, 2, 08190 Sant Cugat, Barcelona
            Technical support: +34 3 589 89 95
            Web : http://www.ubisoft.com/spain
       
            > AUSTRALIA
            3/79 New Beach Road, Darling Point, Sydney NSW 2027
            METRO GAMES Tips and tactics 190 224 0527

            > CHINA
            17F Times Square, 500 Zhan Yang Road,
            Pudong 200122, Shangai
            Technical support: 21/ 64 15 14 33
            Web : http://www.ubisoft.com.cn/

